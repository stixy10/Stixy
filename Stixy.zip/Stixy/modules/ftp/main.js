$(document).ready(function() {
	$('table[style="text-align:center;width:100%;border:1px solid black;background-image:url(../../themes/Revolution/images/wrapper-bg.png);"]').addClass("ftp-login");
	$("ftp-login").removeAttr("style");
	
	});